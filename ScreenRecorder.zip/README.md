# ScreenRecorder
Record screen activity, camera, mic, tab, speakers in 4K HD video format (using ScreenRecorder)
# 
